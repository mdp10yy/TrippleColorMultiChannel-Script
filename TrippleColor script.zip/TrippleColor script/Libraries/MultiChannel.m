function varargout = MultiChannel(varargin)
% MULTICHANNEL MATLAB code for MultiChannel.fig
%      MULTICHANNEL, by itself, creates a new MULTICHANNEL or raises the existing
%      singleton*.
%
%      H = MULTICHANNEL returns the handle to a new MULTICHANNEL or the handle to
%      the existing singleton*.
%
%      MULTICHANNEL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MULTICHANNEL.M with the given input arguments.
%
%      MULTICHANNEL('Property','Value',...) creates a new MULTICHANNEL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before MultiChannel_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to MultiChannel_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help MultiChannel

% Last Modified by GUIDE v2.5 16-Dec-2021 11:49:17

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @MultiChannel_OpeningFcn, ...
                   'gui_OutputFcn',  @MultiChannel_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before MultiChannel is made visible.
function MultiChannel_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to MultiChannel (see VARARGIN)

% Choose default command line output for MultiChannel
clc
global passdata;
passdata=[];
path=load('MultiChannel_readpath.mat');
passdata.readpath=path.readpath;
passdata.interval_cal=[];
passdata.ManualMark_upindex=[];

set(handles.MarkTime,'String','MarkTime');
passdata.InputMark=[];

set(handles.EditInputMark,'Value',1);
set(handles.EditManualMark,'Value',0);


set(handles.smooth_sli,'Value',1.0);

handles.output = hObject;
set(handles.MarkOn_bt,'Value',0);
set(handles.MarkSetting_pan,'Visible','off');
set(handles.CalCorrection_bt,'Value',0);
set(handles.CalCorrection_pan,'Visible','off');

set(handles.EditInputMark,'Value',1);
set(handles.EditManualMark,'Value',0);
set(handles.Zoom_On_radio,'Value',1);
set(handles.cue_channel,'Value',1);
set(handles.cal_pm,'Value',1);
set(handles.Average_bt,'Value',0);
set(handles.Plotting_bt,'Value',0);
set(handles.AveragePlottingPannel,'Visible','off');
% set(handles.Cal,'Visible','on');
% set(handles.Event,'Visible','off');
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes MultiChannel wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = MultiChannel_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function OpenCaldata_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to OpenCaldata (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global passdata;
clc
[filename, pathname] = uigetfile({'*.tdms';'*.mat';'*.CSV'}, 'MultiSelect','off','Open calcium and event data file',passdata.readpath);
if isequal(filename,0)
    msgbox('�û�ȡ����ȡ������');
%     set(handles.filepath_ed,'String','Operation completed failed !!!!');
    return;
end
passdata.file_path_and_name_cal=fullfile(pathname, filename);
passdata.readpath=pathname(1:end-1);
readpath=pathname(1:end-1);
save('MultiChannel_readpath.mat','readpath');
[~,~,passdata.file_part_cal]=fileparts(passdata.file_path_and_name_cal);

if strcmp(passdata.file_part_cal,'.csv')
    passdata.cal=csvread(passdata.file_path_and_name_cal);
elseif strcmp(passdata.file_part_cal,'.tdms')
    file = TDMS_readTDMSFile(passdata.file_path_and_name_cal);
    passdata.cal=cat(1,file.data{3:end})';
elseif strcmp(passdata.file_part_cal,'.mat')
    data=load(passdata.file_path_and_name_cal);
    if isfield(data,'data')
        passdata.cal=data.data;
    else
        msgbox('Please select the correct converted matfile !!!!!') ;
    end
    
end
if isempty(passdata.interval_cal)
    passdata.interval_cal=1/50;
    set(handles.calrate_pm,'Value',2);
end

passdata.channelnum_cal=size(passdata.cal,2)-1;
passdata.cal_read=1;
passdata.cal_raw=passdata.cal;

set(handles.filepath_ed,'String','Cal read completed !!!!');
set(handles.filepath_ed,'String',passdata.file_path_and_name_cal);

set(handles.cal_pm,'String',num2str((1:1:passdata.channelnum_cal)'));
set(handles.cal_pm,'Value',1);

passdata.ManualMark_upindex=[];

DrawData;
msgbox('���ݶ�ȡ�ɹ���������');

guidata(hObject,handles);


function filepath_ed_Callback(hObject, eventdata, handles)
% hObject    handle to filepath_ed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of filepath_ed as text
%        str2double(get(hObject,'String')) returns contents of filepath_ed as a double


% --- Executes during object creation, after setting all properties.
function filepath_ed_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filepath_ed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in MarkOn_bt.
function MarkOn_bt_Callback(hObject, eventdata, handles)
% hObject    handle to MarkOn_bt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
von=get(handles.MarkOn_bt,'Value');
if von==1
    set(handles.MarkSetting_pan,'Visible','on');
elseif von==0
    pos=get(handles.MarkSetting_pan,'Position');
    set(handles.MarkSetting_pan,'Position',[pos(1) pos(2) pos(3) 35]);
    pause(0.03);
    set(handles.MarkSetting_pan,'Position',[pos(1) pos(2) pos(3) 30]);
    pause(0.03);
    set(handles.MarkSetting_pan,'Position',[pos(1) pos(2) pos(3) 25]);
    pause(0.03);
    set(handles.MarkSetting_pan,'Position',[pos(1) pos(2) pos(3) 20]);
    pause(0.03);
    set(handles.MarkSetting_pan,'Position',[pos(1) pos(2) pos(3) 15]);
    pause(0.03);
    set(handles.MarkSetting_pan,'Position',[pos(1) pos(2) pos(3) 10]);
    pause(0.03);
    set(handles.MarkSetting_pan,'Position',[pos(1) pos(2) pos(3) 5]);
    pause(0.03);
    set(handles.MarkSetting_pan,'Visible','off');
    set(handles.MarkSetting_pan,'Position',[pos(1) pos(2) pos(3) pos(4)]);
end



% --- Executes on button press in AllDataPreView_bt.
function AllDataPreView_bt_Callback(hObject, eventdata, handles)
% hObject    handle to AllDataPreView_bt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global passdata;
color=['r','g','b','c','m','y','k'];

if isfield(passdata,'cal') && isfield(passdata,'cue')
    
    if ~isempty(passdata.cal) && ~isempty(passdata.cue)
        figure
        subplot(4,1,1:2)
        t=passdata.interval_cal*(1:1:size(passdata.cal,1));
        for i=1:passdata.channelnum_cal
            eval(['plot(t,passdata.cal(:,',num2str(i+1),'),''',color(i),'''',');']);
            hold on;
        end
        hold off;
        xlabel('Time (s)');
        subplot(4,1,3:4)
        
        interval=passdata.interval_cal/(passdata.length_cue/size(passdata.cal,1));
        t=interval*(1:1:passdata.length_cue);
        for i=1:passdata.channelnum_cue
            eval(['plot(t,passdata.cue(:,',num2str(i),')+(passdata.channelnum_cue-i)*1.1,''',color(i),'''',');']);
            hold on;
        end
        hold off;
        xlabel('Time (s)');
    end
    
end
if isfield(passdata,'cal') && ~isfield(passdata,'cue')
    if ~isempty(passdata.cal)
        figure
        t=passdata.interval_cal*(1:1:size(passdata.cal,1));
        for i=1:passdata.channelnum_cal
            eval(['plot(t,passdata.cal(:,',num2str(i+1),'),''',color(i),'''',');']);
            hold on;
        end
        hold off;
        xlabel('Time (s)');
    end
end





% --- Executes on button press in Average_bt.
function Average_bt_Callback(hObject, eventdata, handles)
% hObject    handle to Average_bt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value=get(handles.Average_bt,'Value');
if value==1
    
    set(handles.Plotting_pannel,'Visible','off');
    if get(handles.Plotting_bt,'Value')==1
        set(handles.Plotting_bt,'Value',0);
        set(handles.Average_pannel,'Visible','on');
        set(handles.Plotting_pannel,'Visible','off');
    else
        pos1=get(handles.AveragePlottingPannel,'Position');
%         pos2=get(handles.DataPreView_axes,'Position');
%         
%         pos2(4)=pos2(4)-pos1(4);
        %     pos2(2)=pos2(2)+pos1(4);
        set(handles.Average_pannel,'Visible','on');
        set(handles.Plotting_pannel,'Visible','off');
%         set(handles.DataPreView_axes,'Position',pos2);
        set(handles.AveragePlottingPannel,'Visible','on');
    end
    %%
else
    
    pos=get(handles.AveragePlottingPannel,'Position');
    set(handles.AveragePlottingPannel,'Position',[pos(1) pos(2)+3 pos(3) pos(4)-3]);
    pause(0.03);
    set(handles.AveragePlottingPannel,'Position',[pos(1) pos(2)+5 pos(3)  pos(4)-5]);
    pause(0.03);
    set(handles.AveragePlottingPannel,'Position',[pos(1) pos(2)+7 pos(3) pos(4)-7]);
    pause(0.03);
    set(handles.AveragePlottingPannel,'Visible','off');
    set(handles.AveragePlottingPannel,'Position',[pos(1) pos(2) pos(3) pos(4)]);
    
%     pos2=get(handles.DataPreView_axes,'Position');
%     pos2(4)=pos2(4)+pos(4);
%     set(handles.DataPreView_axes,'Position',pos2);
end
guidata(hObject,handles);


% --- Executes on button press in Plotting_bt.
function Plotting_bt_Callback(hObject, eventdata, handles)
% hObject    handle to Plotting_bt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value=get(handles.Plotting_bt,'Value');
if value==1
    if get(handles.Average_bt,'Value')==1
        set(handles.Average_bt,'Value',0);
        set(handles.Average_pannel,'Visible','off');
        set(handles.Plotting_pannel,'Visible','on');
%         %%
%         pos1=get(handles.AveragePlottingPannel,'Position');
%         pos2=get(handles.DataPreView_axes,'Position');
%         
%         pos2(4)=pos2(4)-pos1(4);
%         set(handles.DataPreView_axes,'Position',pos2);
%         set(handles.AveragePlottingPannel,'Visible','on');
    else  
        pos1=get(handles.AveragePlottingPannel,'Position');
%         pos2=get(handles.DataPreView_axes,'Position');
        
%         pos2(4)=pos2(4)-pos1(4);
        set(handles.Average_pannel,'Visible','off');
        set(handles.Plotting_pannel,'Visible','on');
%         set(handles.DataPreView_axes,'Position',pos2);
        set(handles.AveragePlottingPannel,'Visible','on');
    end
    %%
else
    
    pos=get(handles.AveragePlottingPannel,'Position');
    set(handles.AveragePlottingPannel,'Position',[pos(1) pos(2)+3 pos(3) pos(4)-3]);
    pause(0.03);
    set(handles.AveragePlottingPannel,'Position',[pos(1) pos(2)+5 pos(3)  pos(4)-5]);
    pause(0.03);
    set(handles.AveragePlottingPannel,'Position',[pos(1) pos(2)+7 pos(3) pos(4)-7]);
    pause(0.03);
    set(handles.AveragePlottingPannel,'Visible','off');
    set(handles.AveragePlottingPannel,'Position',[pos(1) pos(2) pos(3) pos(4)]);
    
%     pos2=get(handles.DataPreView_axes,'Position');
%     pos2(4)=pos2(4)+pos(4);
%     set(handles.DataPreView_axes,'Position',pos2);
end
guidata(hObject,handles);


% --- Executes on button press in OtherFunction_bt.
function OtherFunction_bt_Callback(hObject, eventdata, handles)
% hObject    handle to OtherFunction_bt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc
if isfield(handles,'h1')
    clc
else
    handles.h1=OtherFunction;
end




% --- Executes on button press in CalCorrection_bt.
function CalCorrection_bt_Callback(hObject, eventdata, handles)
% hObject    handle to CalCorrection_bt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
von=get(handles.CalCorrection_bt,'Value');
if von==1
    pos1=get(handles.CalCorrection_pan,'Position');
    pos2=get(handles.DataPreView_axes,'Position');
    pos2(4)=pos2(4)-pos1(4);
    pos2(2)=pos2(2)+pos1(4);
    set(handles.DataPreView_axes,'Position',pos2);
    set(handles.CalCorrection_pan,'Visible','on');
elseif von==0
    pos=get(handles.CalCorrection_pan,'Position');
    set(handles.CalCorrection_pan,'Position',[pos(1) pos(2) pos(3) 15]);
    pause(0.03);
    set(handles.CalCorrection_pan,'Position',[pos(1) pos(2) pos(3) 11]);
    pause(0.03);
    set(handles.CalCorrection_pan,'Position',[pos(1) pos(2) pos(3) 8]);
    pause(0.03);
    set(handles.CalCorrection_pan,'Position',[pos(1) pos(2) pos(3) 4]);
    pause(0.03);
    set(handles.CalCorrection_pan,'Position',[pos(1) pos(2) pos(3) 1]);
    pause(0.03);
    set(handles.CalCorrection_pan,'Visible','off');
    set(handles.CalCorrection_pan,'Position',[pos(1) pos(2) pos(3) pos(4)]);
    pos2=get(handles.DataPreView_axes,'Position');
    pos2(4)=pos2(4)+pos(4);
    pos2(2)=pos2(2)-pos(4);
    set(handles.DataPreView_axes,'Position',pos2);
end

% Hint: get(hObject,'Value') returns toggle state of CalCorrection_bt


% --- Executes on selection change in cal_pm.
function cal_pm_Callback(hObject, eventdata, handles)
% hObject    handle to cal_pm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global passdata;
if ~isfield(passdata,'cal')
    return;
else 
    if isempty(passdata.cal)
        return;
    end
end
DrawData;

% Hints: contents = cellstr(get(hObject,'String')) returns cal_pm contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cal_pm


% --- Executes during object creation, after setting all properties.
function cal_pm_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cal_pm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function smooth_sli_Callback(hObject, eventdata, handles)
% hObject    handle to smooth_sli (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global passdata;
if ~isfield(passdata,'cal')
    return;
else 
    if isempty(passdata.cal)
        return;
    end
end
DrawData;

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function smooth_sli_CreateFcn(hObject, eventdata, handles)
% hObject    handle to smooth_sli (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on selection change in MarkTime.
function MarkTime_Callback(hObject, eventdata, handles)
% hObject    handle to MarkTime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns MarkTime contents as cell array
%        contents{get(hObject,'Value')} returns selected item from MarkTime


% --- Executes during object creation, after setting all properties.
function MarkTime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MarkTime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in ClearMark_bt.
function ClearMark_bt_Callback(hObject, eventdata, handles)
% hObject    handle to ClearMark_bt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc
global passdata
if isfield(passdata,'cal')
    if ~isempty(passdata.cal)&& ~isempty(passdata.ManualMark_upindex)
        dig=['��ȷ���Ƿ�����ֶ����õĴ��ʱ������ݣ�'];
        choice=questdlg(dig, ...
            'Selection Dialog', ...
            'Yes', 'No','No');
        if isempty(choice)
            msgbox('User cancel operation !!!');
            return
        else
            if strcmp(choice,'No')
                msgbox('User cancel operation !!!!');
                return
            else
                %% clear mark
                passdata.ManualMark_upindex=[];
                listbox_cell=cell(1,1);
                listbox_cell{1,1}='MarkTime';
                set(handles.MarkTime,'String',listbox_cell);
                set(handles.MarkTime,'Value',1);
                DrawData;
            end
        end
    end
end

% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in SaveInputMark_bt.
function SaveInputMark_bt_Callback(hObject, eventdata, handles)
% hObject    handle to SaveInputMark_bt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc
global passdata
if isfield(passdata,'cal') && isfield(passdata,'cue')
    if ~isempty(passdata.cal) && ~isempty(passdata.cue)
        %         passdata.InputMark.Finalyupindex_' num2str(i) '=exam_upindex;']);
        if isfield(passdata,'InputMark')
            %% 
            dig=['��ȷ���Ƿ񱣴��޸Ĺ���Ĵ�����ݣ�ȷ���޸Ĺ����ʹ��ResetMark�ָ���ʼ�Ĵ��ֵ��������'];
            choice=questdlg(dig, ...
                'Selection Dialog', ...
                'Yes', 'No','No');
            if isempty(choice)
                msgbox('User cancel operation !!!');
                return
            else
                if strcmp(choice,'No')
                    msgbox('User cancel operation !!!!');
                    return
                else
                    %% save mark
                    for i=1:size(passdata.cue,2)
                        eval(['passdata.InputMark.Finalyupindex_' num2str(i) '=passdata.InputMark.upindex_' num2str(i) ';']);
                    end
                end
            end
            
            
        end
    end
end




% --- Executes on button press in ResetMark_bt.
function ResetMark_bt_Callback(hObject, eventdata, handles)
% hObject    handle to ResetMark_bt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc
global passdata;
if isfield(passdata,'cal') && isfield(passdata,'cue')
    
    if ~isempty(passdata.cal) && ~isempty(passdata.cue)
        if isfield(passdata,'InputMark')
            dig=['�Ƿ�Ҫ���ô��ʱ�䵽��ʼ����¼ʱ��λ�ã�'];
            choice=questdlg(dig, ...
                'Selection Dialog', ...
                'Yes', 'No','No');
            if isempty(choice)
                msgbox('User cancel operation !!!');
                return
            else
                if strcmp(choice,'No')
                    msgbox('User cancel operation !!!!');
                    return
                else
                    %% save mark
                    for i=1:size(passdata.cue,2)
                        cue=smooth(passdata.cue(:,i),5);
                        cue(cue<1)=0;
                        cue(cue>=1)=1;
                        current_cue=cue;
                        exam_upindex=1+find(diff(current_cue)==1)'-4;
                        exam_trialnum = size(exam_upindex,2);
                        eval(['passdata.InputMark.upindex_' num2str(i) '=exam_upindex;']);
                        eval(['passdata.InputMark.Finalyupindex_' num2str(i) '=exam_upindex;']);
                        eval(['passdata.InputMark.trialnum_' num2str(i) '=exam_trialnum;']);
                    end
                end
            end
            %%
        end
    end
end


% --- Executes on selection change in cue_channel.
function cue_channel_Callback(hObject, eventdata, handles)
% hObject    handle to cue_channel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global passdata;
if ~isfield(passdata,'cue')
    return;
else 
    if isempty(passdata.cue)
        return;
    end
end
DrawData;

% Hints: contents = cellstr(get(hObject,'String')) returns cue_channel contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cue_channel


% --- Executes during object creation, after setting all properties.
function cue_channel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cue_channel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function correcttime1_ed_Callback(hObject, eventdata, handles)
% hObject    handle to correcttime1_ed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of correcttime1_ed as text
%        str2double(get(hObject,'String')) returns contents of correcttime1_ed as a double


% --- Executes during object creation, after setting all properties.
function correcttime1_ed_CreateFcn(hObject, eventdata, handles)
% hObject    handle to correcttime1_ed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function correcttime2_ed_Callback(hObject, eventdata, handles)
% hObject    handle to correcttime2_ed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of correcttime2_ed as text
%        str2double(get(hObject,'String')) returns contents of correcttime2_ed as a double


% --- Executes during object creation, after setting all properties.
function correcttime2_ed_CreateFcn(hObject, eventdata, handles)
% hObject    handle to correcttime2_ed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in lambda_pm.
function lambda_pm_Callback(hObject, eventdata, handles)
% hObject    handle to lambda_pm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns lambda_pm contents as cell array
%        contents{get(hObject,'Value')} returns selected item from lambda_pm


% --- Executes during object creation, after setting all properties.
function lambda_pm_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lambda_pm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ploy_ed_Callback(hObject, eventdata, handles)
% hObject    handle to ploy_ed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ploy_ed as text
%        str2double(get(hObject,'String')) returns contents of ploy_ed as a double


% --- Executes during object creation, after setting all properties.
function ploy_ed_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ploy_ed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in lambdacorrect_bt.
function lambdacorrect_bt_Callback(hObject, eventdata, handles)
% hObject    handle to lambdacorrect_bt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc
global passdata;
if isfield(passdata,'cal')
    if ~isempty(passdata.cal)
        value=get(handles.lambda_pm,'Value')+4;
        correction_time=str2num(get(handles.correcttime1_ed,'String'));
        if isempty(correction_time)
            msgbox('��������ȷ��CorrecttionTimes/s�Ŀ�ʼʱ�䣬ʱ���ʽӦ������ֵ������������ţ�����');
            return
        end
        correction_time_2=str2num(get(handles.correcttime2_ed,'String'));
        if isempty(correction_time_2)
            msgbox('��������ȷ��CorrecttionTimes/s�Ľ���ʱ�䣬ʱ���ʽӦ������ֵ������������ţ�����');
            return
        end
        %% �ж�ʱ���ʽ�Ƿ���ȷ
        interval=passdata.interval_cal;
        maxtime=size(passdata.cal,1)*interval;
        if correction_time>correction_time_2
            p=correction_time;
            correction_time=correction_time_2;
            correction_time_2=p;
        end
        if correction_time<=0
            correction_time=0;
        end
        if correction_time_2<=0
            return;
        end
        if correction_time_2>maxtime
            correction_time_2=maxtime;
        end
        set(handles.correcttime1_ed,'String',num2str(correction_time));
        set(handles.correcttime2_ed,'String',num2str(correction_time_2));
        %% ������ʼλ��
        cal_index=get(handles.cal_pm,'Value');
        start_index=correction_time/interval;
        end_index=correction_time_2/interval;
        if start_index==0
            start_index=1;
        end
        correction_data=passdata.cal(start_index:end_index,cal_index+1);
        correction_data=correction_data';
        %% ���������λ��
        if round(correction_time/interval)==0
            part_index=0;
            part_index_end=end_index+1;
        else
            part_index=round(correction_time/interval)-1;
            part_index_end=end_index+1;
        end
        %% �洢���λ������
        raw_start=correction_data(1);
        raw_end=correction_data(end);
        %% ����
        lambda=10^(value+1);
        [correction_data,~]=airPLS(correction_data, lambda,2,0.05);
        if isempty(correction_data)
            msgbox('��ʱ��β��ɽ������жϸ�ͨ�������Ƿ������Ч��Ϣ������');
            return;
        end
        correction_data=correction_data+(raw_start-correction_data(1));
        correction_data=correction_data';
        if part_index==0
            passdata.correction_data=[correction_data;passdata.cal(part_index_end:end,cal_index+1)-raw_end+correction_data(end)];
            passdata.correction_index=1;
            passdata.cal_correction_index=cal_index;
        else
            passdata.correction_data=[passdata.cal(1:part_index,cal_index+1);correction_data;passdata.cal(part_index_end:end,cal_index+1)-raw_end+correction_data(end)];
            passdata.correction_index=1;
            passdata.cal_correction_index=cal_index;
        end
        DrawData_Correct;
    end
end

% --- Executes on button press in ploycorrect_bt.
function ploycorrect_bt_Callback(hObject, eventdata, handles)
% hObject    handle to ploycorrect_bt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc
global passdata;
if isfield(passdata,'cal')
    if ~isempty(passdata.cal)
        value=get(handles.lambda_pm,'Value')+4;
        correction_time=str2num(get(handles.correcttime1_ed,'String'));
        if isempty(correction_time)
            msgbox('��������ȷ��CorrecttionTimes/s�Ŀ�ʼʱ�䣬ʱ���ʽӦ������ֵ������������ţ�����');
            return
        end
        correction_time_2=str2num(get(handles.correcttime2_ed,'String'));
        if isempty(correction_time_2)
            msgbox('��������ȷ��CorrecttionTimes/s�Ľ���ʱ�䣬ʱ���ʽӦ������ֵ������������ţ�����');
            return
        end
        %% �ж�ʱ���ʽ�Ƿ���ȷ
        interval=passdata.interval_cal;
        maxtime=size(passdata.cal,1)*interval;
        if correction_time>correction_time_2
            p=correction_time;
            correction_time=correction_time_2;
            correction_time_2=p;
        end
        if correction_time<=0
            correction_time=0;
        end
        if correction_time_2<=0
            return;
        end
        if correction_time_2>maxtime
            correction_time_2=maxtime;
        end
        set(handles.correcttime1_ed,'String',num2str(correction_time));
        set(handles.correcttime2_ed,'String',num2str(correction_time_2));
        %% ������ʼλ��
        cal_index=get(handles.cal_pm,'Value');
        start_index=correction_time/interval;
        end_index=correction_time_2/interval;
        if start_index==0
            start_index=1;
        end
        correction_data=passdata.cal(start_index:end_index,cal_index+1);
        correction_data=correction_data';
        %% ���������λ��
        if round(correction_time/interval)==0
            part_index=0;
            part_index_end=end_index+1;
        else
            part_index=round(correction_time/interval)-1;
            part_index_end=end_index+1;
        end
        %% �洢���λ������
        raw_start=correction_data(1);
        raw_end=correction_data(end);
        %% ����
        values = correction_data;
        [xData, yData] = prepareCurveData( [], values );
        n=2;
        [p,s,mu] = polyfit(xData,yData,n);
        fit_y = polyval(p,xData,[],mu);
        correction_data= values-fit_y';
        %%
        if isempty(correction_data)
            msgbox('��ʱ��β��ɽ������жϸ�ͨ�������Ƿ������Ч��Ϣ������');
            return;
        end
        correction_data=correction_data+(raw_start-correction_data(1));
        correction_data=correction_data';
        if part_index==0
            passdata.correction_data=[correction_data;passdata.cal(part_index_end:end,cal_index+1)-raw_end+correction_data(end)];
            passdata.correction_index=2;
            passdata.cal_correction_index=cal_index;
        else
            passdata.correction_data=[passdata.cal(1:part_index,cal_index+1);correction_data;passdata.cal(part_index_end:end,cal_index+1)-raw_end+correction_data(end)];
            passdata.correction_index=2;
            passdata.cal_correction_index=cal_index;
        end
        DrawData_Correct;
    end
end



% --- Executes on button press in LambdaSaveCorrect_bt.
function LambdaSaveCorrect_bt_Callback(hObject, eventdata, handles)
% hObject    handle to LambdaSaveCorrect_bt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc
global passdata;
if isfield(passdata,'correction_data') && isfield(passdata,'cal')
    if ~isempty(passdata.correction_data) && ~isempty(passdata.cal)
        if isfield(passdata,'cal_correction_index') && passdata.correction_index==1
            if size(passdata.cal,2)>=(passdata.cal_correction_index+1)
                dig=['Please make sure whether to replace the ' num2str(passdata.cal_correction_index) ' channel data  with the correction data'];
                choice=questdlg(dig, ...
                    'Selection Dialog', ...
                    'Yes', 'No','No');
                if isempty(choice)
                    msgbox('User cancel operation !!!');
                else
                    if strcmp(choice,'No')
                        msgbox('User cancel operation !!!!');
                    else
                        if isfield(passdata,'cal')
                            if ~isempty(passdata.cal)
                                passdata.cal(:,passdata.cal_correction_index+1)=passdata.correction_data;
                                set(handles.cal_pm,'Value',passdata.cal_correction_index);
                                DrawData;
                                msgbox('Operation succeeds !!!');
                            end
                        end
                    end
                end
            end
        end
    end
end


% --- Executes on button press in PloySaveCorrect_bt.
function PloySaveCorrect_bt_Callback(hObject, eventdata, handles)
% hObject    handle to PloySaveCorrect_bt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc
global passdata;
if isfield(passdata,'correction_data') && isfield(passdata,'cal')
    if ~isempty(passdata.correction_data) && ~isempty(passdata.cal)
        if isfield(passdata,'cal_correction_index') && passdata.correction_index==2
            if size(passdata.cal,2)>=(passdata.cal_correction_index+1)
                dig=['Please make sure whether to replace the ' num2str(passdata.cal_correction_index) ' channel data  with the correction data'];
                choice=questdlg(dig, ...
                    'Selection Dialog', ...
                    'Yes', 'No','No');
                if isempty(choice)
                    msgbox('User cancel operation !!!');
                else
                    if strcmp(choice,'No')
                        msgbox('User cancel operation !!!!');
                    else
                        if isfield(passdata,'cal')
                            if ~isempty(passdata.cal)
                                passdata.cal(:,passdata.cal_correction_index+1)=passdata.correction_data;
                                set(handles.cal_pm,'Value',passdata.cal_correction_index);
                                DrawData;
                                msgbox('Operation succeeds !!!');
                            end
                        end
                    end
                end
            end
        end
    end
end



% --- Executes on button press in SaveSmooth_bt.
function SaveSmooth_bt_Callback(hObject, eventdata, handles)
% hObject    handle to SaveSmooth_bt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global passdata;
cal_index=get(handles.cal_pm,'Value');
smoothval=round(get(handles.smooth_sli,'Value'));
if smoothval>1
    dig=['Please make sure whether to replace the ' num2str(cal_index) ' channel data  with the smooth data'];
    choice=questdlg(dig, ...
        'Selection Dialog', ...
        'Yes', 'No','No');
    if isempty(choice)
        msgbox('User cancel operation !!!');
    else
        if strcmp(choice,'No')
            msgbox('User cancel operation !!!!');
        else
            if isfield(passdata,'cal')
                if ~isempty(passdata.cal)
                    passdata.cal(:,cal_index+1)=smooth(passdata.cal(:,cal_index+1),smoothval);
                    DrawData;
                    set(handles.smooth_sli,'Value',1);
                    msgbox('Operation succeeds !!!');
                end
            end
        end
    end
end






% --- Executes on selection change in calrate_pm.
function calrate_pm_Callback(hObject, eventdata, handles)
% hObject    handle to calrate_pm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
rate_index=get(handles.calrate_pm,'Value');
global passdata;
current_interval=passdata.interval_cal;

switch rate_index
    case 1
        passdata.interval_cal=1/25;
    case 2
        passdata.interval_cal=1/50;
    case 3
        passdata.interval_cal=1/100;
end
if isfield(passdata,'ManualMark_upindex')
    passdata.ManualMark_upindex=passdata.ManualMark_upindex*(passdata.interval_cal/current_interval);
end
if isfield(passdata,'MarkIndex')
    passdata.MarkIndex=passdata.MarkIndex*(passdata.interval_cal/current_interval);
end
%%

% if isfield(passdata,'cue')
%     if isfield(passdata,'InputMark')
%         for i=1:size(passdata.cue,2)
%             
%             eval(['passdata.InputMark.upindex_' num2str(i) '=passdata.InputMark.upindex_' num2str(i) '*(passdata.interval_cal/current_interval);']);
%             eval(['passdata.InputMark.Finalyupindex_' num2str(i) '=passdata.InputMark.Finalyupindex_' num2str(i) '*(passdata.interval_cal/current_interval);']);
% %             eval(['passdata.InputMark.trialnum_' num2str(i) '=exam_trialnum;']);
%         end
%     end
% end
%%
DrawData;

guidata(hObject,handles);


% Hints: contents = cellstr(get(hObject,'String')) returns calrate_pm contents as cell array
%        contents{get(hObject,'Value')} returns selected item from calrate_pm


% --- Executes during object creation, after setting all properties.
function calrate_pm_CreateFcn(hObject, eventdata, handles)
% hObject    handle to calrate_pm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function OpenEventData_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to OpenEventData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global passdata;
[filename, pathname] = uigetfile({'*.tdms';'*.mat';'*.CSV'}, 'Open calcium_data file',passdata.readpath);
if isequal(filename,0)
    msgbox('�û�ȡ����ȡ������');
%     set(handles.filepath_ed,'String','Operation completed failed !!!!');
    return;
end

passdata.file_path_and_name_cue = fullfile(pathname, filename);
%% ��ȡcue����
[~,~,filepart_cue]=fileparts(passdata.file_path_and_name_cue);
% [filename,pathname]=uigetfile({'*.tdms'},'Open cue_data file','MultiSelect','on');%��ȡ���mat�ļ�
% handles.file_path_and_name_cue = fullfile(pathname, filename(i));
if strcmp(filepart_cue,'.csv')
    cue=csvread(passdata.file_path_and_name_cue);
elseif strcmp(filepart_cue,'.tdms')
    file = TDMS_readTDMSFile(passdata.file_path_and_name_cue);
    cue=cat(1,file.data{3:end})';
elseif strcmp(filepart_cue,'.mat')
    cue=load(passdata.file_path_and_name_cue);
    if isfield(cue,'data')
        cue=cue.data;
    else
        msgbox('Please select the correct converted matfile !!!!!') ;
    end
end
%%
if isempty(cue)
    msgbox('Event���ݶ�ȡʧ�ܣ���');
    return
else
    passdata.cue=cue;
end
%%      ����event����
passdata.file_part_cue=filepart_cue;
passdata.channelnum_cue=size(passdata.cue,2);
passdata.length_cue=size(passdata.cue,1);
%% ����eventÿ��ͨ����������λ��
for i=1:passdata.channelnum_cue
    cue=smooth(passdata.cue(:,i),5);
    cue(cue<1)=0;
    cue(cue>=1)=1;
    current_cue=cue;
    exam_upindex=1+find(diff(current_cue)==1)'-4;
    exam_trialnum = size(exam_upindex,2);
    eval(['passdata.InputMark.upindex_' num2str(i) '=exam_upindex;']);
    eval(['passdata.InputMark.Finalyupindex_' num2str(i) '=exam_upindex;']);
    eval(['passdata.InputMark.trialnum_' num2str(i) '=exam_trialnum;']);  
end
set(handles.cue_channel,'String',num2str((1:1:passdata.channelnum_cue)'));
set(handles.cue_channel,'Value',1);
%% 
passdata.cue_read=1;
set(handles.filepath_ed,'String','Event read completed !!!!');

DrawData;

msgbox('Event���ݶ�ȡ�ɹ���������');
guidata(hObject,handles);


% --- Executes on button press in EditInputMark.
function EditInputMark_Callback(hObject, eventdata, handles)
% hObject    handle to EditInputMark (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if get(handles.EditInputMark,'Value')==1
    set(handles.EditInputMark,'Value',1);
    set(handles.EditManualMark,'Value',0);
    global passdata;
    DrawData;
elseif get(handles.EditInputMark,'Value')==0
    set(handles.EditInputMark,'Value',0);
    set(handles.EditManualMark,'Value',1);
    global passdata;
    DrawData;
end

% Hint: get(hObject,'Value') returns toggle state of EditInputMark


% --- Executes on button press in EditManualMark.
function EditManualMark_Callback(hObject, eventdata, handles)
% hObject    handle to EditManualMark (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if get(handles.EditManualMark,'Value')==1
    set(handles.EditInputMark,'Value',0);
    set(handles.EditManualMark,'Value',1);
    global passdata;
    DrawData;
elseif get(handles.EditManualMark,'Value')==0
    set(handles.EditInputMark,'Value',1);
    set(handles.EditManualMark,'Value',0);
    global passdata;
    DrawData;
end

% Hint: get(hObject,'Value') returns toggle state of EditManualMark


% --- Executes on button press in Zoom_On_radio.
function Zoom_On_radio_Callback(hObject, eventdata, handles)
% hObject    handle to Zoom_On_radio (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global passdata;
handles.uipanel1;
if get(handles.Zoom_On_radio,'Value')
%     hA = gca;
%     zoom(hA, 'reset');
    zoom xon;
    %     DrawData;
elseif get(handles.Zoom_On_radio,'Value')==0
    if isfield(passdata,'cal')
        if ~isempty(passdata.cal)
%             hA = gca;
%             zoom(hA, 'reset');
            zoom off
            set(gcf,'WindowButtonMotionFcn',{@ButtonMotionFcn,handles},'WindowButtonDownFcn',@ButttonDownFcn,'WindowButtonUpFcn',{@ButttonUpFcn,handles});
            %             DrawData;
        else
            set(handles.Zoom_On_radio,'Value',1);
        end
    else
        set(handles.Zoom_On_radio,'Value',1);
    end
end

% Hint: get(hObject,'Value') returns toggle state of Zoom_On_radio


% --- Executes on button press in togglebutton2.
function togglebutton2_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton2



function pretime_Callback(hObject, eventdata, handles)
% hObject    handle to pretime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pretime as text
%        str2double(get(hObject,'String')) returns contents of pretime as a double


% --- Executes during object creation, after setting all properties.
function pretime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pretime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function posttime_Callback(hObject, eventdata, handles)
% hObject    handle to posttime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of posttime as text
%        str2double(get(hObject,'String')) returns contents of posttime as a double


% --- Executes during object creation, after setting all properties.
function posttime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to posttime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function control_1_Callback(hObject, eventdata, handles)
% hObject    handle to control_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of control_1 as text
%        str2double(get(hObject,'String')) returns contents of control_1 as a double


% --- Executes during object creation, after setting all properties.
function control_1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to control_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function control_2_Callback(hObject, eventdata, handles)
% hObject    handle to control_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of control_2 as text
%        str2double(get(hObject,'String')) returns contents of control_2 as a double


% --- Executes during object creation, after setting all properties.
function control_2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to control_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Avearge_pb.
function Avearge_pb_Callback(hObject, eventdata, handles)
% hObject    handle to Avearge_pb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc
global passdata
if isfield(passdata,'cal')
    if ~isempty(passdata.cal)
        %%
        value=get(handles.EditInputMark,'Value');
        if value==1
            if ~isfield(passdata,'cue')
                return
            else
                if isempty(passdata.cue)
                    return
                end
            end
            cue_index=get(handles.cue_channel,'Value');
            eval(['upindex=passdata.InputMark.Finalyupindex_' num2str(cue_index) ';']);
            if isempty(upindex)
                msgbox('��ǰCueͨ��δ��⵽���ʱ��㣬������ȷ�ϴ��ͨ������');
                return
            end
            interval_cue=passdata.interval_cal/(passdata.length_cue/size(passdata.cal,1));
            upindex=upindex*interval_cue;
        elseif value==0
            upindex=passdata.ManualMark_upindex;
            if isempty(upindex)
                msgbox('�ֶ����ģʽδ��⵽���ʱ��㣬������ȷ���ֶ����ģʽ�Ƿ�������Ǵ�������');
                return
            end
        end
        cal_index=get(handles.cal_pm,'Value');
        currentcall=passdata.cal(:,cal_index+1);
        pre_time=str2num(get(handles.pretime,'String'));
        %% �ж�����ʱ���ʽ
        if isempty(pre_time)
            msgbox('��������ȷ�Ŀ�ʼʱ���ʽ!!!');
            return;
        end
        if pre_time>=0
            msgbox('��ʼʱ��������ø�ֵ!!!');
            return;
        end
        post_time=str2num(get(handles.posttime,'String'));
        if isempty(post_time)
            msgbox('��������ȷ�Ŀ�ʼʱ���ʽ!!!');
            return;
        end
        %% �ж�controltimeʱ���趨
        control_from=str2num(get(handles.control_1,'String'));
        if isempty(control_from)
            msgbox('��������ȷ��ʱ���ʽ!!!');
            return;
        end
        control_to=str2num(get(handles.control_2,'String'));
        if isempty(control_to)
            msgbox('��������ȷ��ʱ���ʽ!!!');
            return;
        end
        %% ���clims
        clims1=str2num(get(handles.clims_1,'String'));
        clims2=str2num(get(handles.clims_2,'String'));
        if isempty(clims1)||isempty(clims2)
            clims=[];
            set(handles.clims_1,'String','0');
            set(handles.clims_2,'String','0');
        elseif clims1>clims2
            p=clims1;
            clims1=clims2;
            clims2=p;
            set(handles.clims_1,'String',num2str(clims1));
            set(handles.clims_2,'String',num2str(clims2));
            clims=zeros(1,2);
            clims(1)=clims1;
            clims(2)=clims2;
        elseif clims1==clims2
            clims=[];
        else
            clims=zeros(1,2);
            clims(1)=clims1;
            clims(2)=clims2;
        end
        %% offset���
        offset=str2num(get(handles.offset_average,'String'));
        if isempty(offset)
            offset=0;
        elseif length(offset)>passdata.channelnum_cal
            offset=offset(cal_index);
            set(handles.offset_average,'String',num2str(offset));
        elseif length(offset)>=1&& length(offset)<passdata.channelnum_cal
            offset=offset(1);
            set(handles.offset_average,'String',num2str(offset));
        end
        %% ����������
        trailnum=length(upindex);
        trialnumtemp=trailnum;
        
        %% ��⿪ʼ���Ƿ񳬳���Χʱ���
        for i=1:trailnum
            if upindex(i) < abs(pre_time)
                upindex(i)=0;
                trialnumtemp = trialnumtemp-1;
            end
        end
        upindex(upindex==0)=[];
        trialnum=trialnumtemp;
        if trialnum==0
            msgbox('����ʧ�ܣ���ȷ�����ʱ���ʱ���Ƿ񳬹���ʼʱ��㣡��');
            return
        end
        %% ���������Ƿ񳬳���Χʱ���
        for i=1:trailnum
            if upindex(i)+post_time>size(passdata.cal,1)*passdata.interval_cal
                upindex(i)=0;
                trialnumtemp = trialnumtemp-1;
            end
        end
        trialnum=trialnumtemp;
        upindex(upindex==0)=[];
        if trialnum==0
            msgbox('����ʧ�ܣ���ȷ�����ʱ���ʱ���Ƿ񳬹�����ʱ���!!!');
            return
        end
        %% ��ʼ����
        upindex=round(upindex/passdata.interval_cal);
        z_score=get(handles.Zsocre_avearge,'Value');
        alpha_check=get(handles.Alpha_On,'Value');
        trigger1_times = trigger_times_pretreatment_multi(upindex,1,passdata.interval_cal,length(upindex),[]);
        [psth1,psth1_mean,psth1_sem] = psth_wave2_multi(trigger1_times,passdata.interval_cal,currentcall,-pre_time,post_time,control_from,control_to,offset,z_score);
        times = pre_time:passdata.interval_cal:post_time;
        if alpha_check==1
            psth1Ctrl=psth1(:,times<0);
            ctrl = reshape(psth1Ctrl,size(psth1Ctrl,1).*size(psth1Ctrl,2),1);
            psth1Data = nanmean(psth1);  %ÿһ�����ݵ�ƽ��ֵ��
            baseMean = nanmean(ctrl);
            mCtrl = nanmean(psth1Ctrl,2);
            dataCtrl =  repmat(mCtrl,1,size(psth1,2));
            dif=psth1-dataCtrl; %difference between conditions
            poscolor=[238 44 44];
            negcolor=[0 0 255];
            alpha_level = str2num(get(handles.Alpha,'String'));
            [cpval, ~, ~, ~, ~]=mult_comp_perm_t1(dif,size(psth1,2),0,alpha_level);
            posSigIdx = psth1Data > baseMean & cpval<alpha_level;
            negSigIdx = psth1Data < baseMean & cpval<alpha_level;
            %%
            
            if z_score==1
                figure('NumberTitle', 'off', 'Name', 'Z_score data Preview ');
                areaErrorbar(times,psth1);
            else
                figure('NumberTitle', 'off', 'Name', 'DeltaF/F(%) data Preview ');
                areaErrorbar(times,psth1);
            end
            xlabel('Time (s)');
            set(gca,'Tickdir','out');
            if z_score==1
                ylabel('z-score');
            else
                ylabel('deltaF/F(%)');
            end
            sigPntPlot2(times,psth1Data,posSigIdx,negSigIdx,poscolor,negcolor);
            fig1 = figure;
            heatmapPlot(psth1,passdata.interval_cal,-pre_time,0.1,fig1,clims);
        else
            if z_score==1
                figure('NumberTitle', 'off', 'Name', 'Z_score data Preview ');
                drawErrorLine(times,psth1_mean,psth1_sem,'red',0.5);
            else
                figure('NumberTitle', 'off', 'Name', 'DeltaF/F(%) data Preview ');
                drawErrorLine(times,psth1_mean,psth1_sem,'red',0.5);
            end
            xlabel('Time (s)');
            set(gca,'Tickdir','out');
            if z_score==1
                ylabel('z-score');
            else
                ylabel('deltaF/F(%)');
            end
            fig1 = figure('NumberTitle', 'off', 'Name', 'Heatmap Preview ');
            heatmapPlot(psth1,passdata.interval_cal,-pre_time,0.1,fig1,clims); 
        end
        
        save(strrep(passdata.file_path_and_name_cal,passdata.file_part_cal,'_averagedata.mat'),'times','psth1','psth1_mean','psth1_sem');
        
    end
end

% --- Executes on button press in AveragePlayBack.
function AveragePlayBack_Callback(hObject, eventdata, handles)
% hObject    handle to AveragePlayBack (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc
handles=guidata(hObject);
global passdata;
[filename, pathname] = uigetfile({'*.mat'},'MultiSelect','off','Open trail_data file',passdata.readpath);
if isequal(filename,0)
    return;
end
filename = fullfile(pathname, filename);
[~,~,file_part_trail]=fileparts(filename);
if strcmp(file_part_trail,'.mat')
    
    data=load(filename);
    if ~isfield(data,'psth1_mean')
        msgbox('Failed!Please make sure the trail data is correct !!!!');
        
        return
    end
    
    figure('NumberTitle', 'off', 'Name', 'Trail data Preview ');
    drawErrorLine(data.times,data.psth1_mean,data.psth1_sem,'red',0.5);
    
    
    ylabel('deltaF/F(%)');
   
    
    figure('NumberTitle', 'off', 'Name', 'Heatmap Preview ');
    
    smoothed_data = linearSmooth1(data.psth1,0.1);
    
   
    imagesc(data.times,1:1:size(data.psth1,1),smoothed_data,[min(min(smoothed_data)),max(max(smoothed_data))]);

else
    msgbox('Failed!Please make sure the trail data is correct !!!!');
    return;
end
guidata(hObject,handles);



function clims_1_Callback(hObject, eventdata, handles)
% hObject    handle to clims_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of clims_1 as text
%        str2double(get(hObject,'String')) returns contents of clims_1 as a double


% --- Executes during object creation, after setting all properties.
function clims_1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to clims_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function clims_2_Callback(hObject, eventdata, handles)
% hObject    handle to clims_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of clims_2 as text
%        str2double(get(hObject,'String')) returns contents of clims_2 as a double


% --- Executes during object creation, after setting all properties.
function clims_2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to clims_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Alpha_Callback(hObject, eventdata, handles)
% hObject    handle to Alpha (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Alpha as text
%        str2double(get(hObject,'String')) returns contents of Alpha as a double


% --- Executes during object creation, after setting all properties.
function Alpha_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Alpha (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Alpha_On.
function Alpha_On_Callback(hObject, eventdata, handles)
% hObject    handle to Alpha_On (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Alpha_On


% --- Executes on button press in DeltaF_F_average.
function DeltaF_F_average_Callback(hObject, eventdata, handles)
% hObject    handle to DeltaF_F_average (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value=get(handles.DeltaF_F_average,'Value');
if value==1
    set(handles.Zsocre_avearge,'Value',0);
elseif value==0
    set(handles.Zsocre_avearge,'Value',1);
end
guidata(hObject,handles);

% Hint: get(hObject,'Value') returns toggle state of DeltaF_F_average


% --- Executes on button press in Zsocre_avearge.
function Zsocre_avearge_Callback(hObject, eventdata, handles)
% hObject    handle to Zsocre_avearge (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value=get(handles.Zsocre_avearge,'Value');
if value==1
    set(handles.DeltaF_F_average,'Value',0);
elseif value==0
    set(handles.DeltaF_F_average,'Value',1);
end
guidata(hObject,handles);

% Hint: get(hObject,'Value') returns toggle state of Zsocre_avearge



function offset_average_Callback(hObject, eventdata, handles)
% hObject    handle to offset_average (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of offset_average as text
%        str2double(get(hObject,'String')) returns contents of offset_average as a double


% --- Executes during object creation, after setting all properties.
function offset_average_CreateFcn(hObject, eventdata, handles)
% hObject    handle to offset_average (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function evalutiontime1_Callback(hObject, eventdata, handles)
% hObject    handle to evalutiontime1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of evalutiontime1 as text
%        str2double(get(hObject,'String')) returns contents of evalutiontime1 as a double


% --- Executes during object creation, after setting all properties.
function evalutiontime1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to evalutiontime1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function evalutiontime2_Callback(hObject, eventdata, handles)
% hObject    handle to evalutiontime2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of evalutiontime2 as text
%        str2double(get(hObject,'String')) returns contents of evalutiontime2 as a double


% --- Executes during object creation, after setting all properties.
function evalutiontime2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to evalutiontime2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function control_plot_1_Callback(hObject, eventdata, handles)
% hObject    handle to control_plot_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of control_plot_1 as text
%        str2double(get(hObject,'String')) returns contents of control_plot_1 as a double


% --- Executes during object creation, after setting all properties.
function control_plot_1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to control_plot_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function control_plot_2_Callback(hObject, eventdata, handles)
% hObject    handle to control_plot_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of control_plot_2 as text
%        str2double(get(hObject,'String')) returns contents of control_plot_2 as a double


% --- Executes during object creation, after setting all properties.
function control_plot_2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to control_plot_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in DeltaF_F_plot.
function DeltaF_F_plot_Callback(hObject, eventdata, handles)
% hObject    handle to DeltaF_F_plot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value=get(handles.DeltaF_F_plot,'Value');
if value==1
    set(handles.Zsocre_plot,'Value',0);
elseif value==0
    set(handles.Zsocre_plot,'Value',1);
end
guidata(hObject,handles);

% Hint: get(hObject,'Value') returns toggle state of DeltaF_F_plot


% --- Executes on button press in Zsocre_plot.
function Zsocre_plot_Callback(hObject, eventdata, handles)
% hObject    handle to Zsocre_plot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value=get(handles.Zsocre_plot,'Value');
if value==1
    set(handles.DeltaF_F_plot,'Value',0);
elseif value==0
    set(handles.DeltaF_F_plot,'Value',1);
end
guidata(hObject,handles);

% Hint: get(hObject,'Value') returns toggle state of Zsocre_plot



function offset_plot_Callback(hObject, eventdata, handles)
% hObject    handle to offset_plot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of offset_plot as text
%        str2double(get(hObject,'String')) returns contents of offset_plot as a double


% --- Executes during object creation, after setting all properties.
function offset_plot_CreateFcn(hObject, eventdata, handles)
% hObject    handle to offset_plot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Plotting.
function Plotting_Callback(hObject, eventdata, handles)
% hObject    handle to Plotting (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc
global passdata
if isfield(passdata,'cal')
    if ~isempty(passdata.cal)
        zscore=get(handles.Zsocre_plot,'Value');
        %%
        if isempty(str2num(get(handles.control_plot_1,'String')))
            return
        else
            controltime(1)=str2num(get(handles.control_plot_1,'String'));
        end
        if isempty(str2num(get(handles.control_plot_2,'String')))
            return
        else
            controltime(2)=str2num(get(handles.control_plot_2,'String'));
        end
        %%
        if isempty(str2num(get(handles.evalutiontime1,'String')))
            return
        else
            evaluationtime(1)=str2num(get(handles.evalutiontime1,'String'));
        end
        
        if isempty(str2num(get(handles.evalutiontime2,'String')))
            return
        else
           evaluationtime(2)=str2num(get(handles.evalutiontime2,'String')); 
        end
        
        offset = str2num(get(handles.offset_plot,'String'));
        if isempty(offset)
            offset=0;
        end
        %%
        cal_index=get(handles.cal_pm,'Value');
        interval=passdata.interval_cal;
        %%
        evaluationtime(evaluationtime(:)<=0)=1;
        evaluationtime(evaluationtime(:)>=size(passdata.cal,1)*interval)=size(passdata.cal,1)*interval;
        if evaluationtime(1)>evaluationtime(2)
            p= evaluationtime(1);
            evaluationtime(1)=evaluationtime(2);
            evaluationtime(2)=p;
            set(handles.evalutiontime1,'String',num2str(evaluationtime(1)));
            set(handles.evalutiontime2,'String',num2str(evaluationtime(2)));
        end
        
        if evaluationtime(1)==evaluationtime(2)
            evaluationtime=[];
            set(handles.evalutiontime1,'String','0');
            set(handles.evalutiontime2,'String','0');
            msgbox(' ʱ�䷶Χ���ô���������ʼʱ�������Ƿ���ȷ���߳�����ʱ��!!');
            return;
        end
        %%
        if length(offset)~=size(passdata.cal,2)-1
            if ~isempty(offset)
                current_offset=offset(1);
            else
                current_offset=0;
            end
        else
            current_offset=offset(cal_index);
        end
        %%
        controltime(controltime(:)>=size(passdata.cal,1)*interval)=size(passdata.cal,1)*interval;
        controltime(controltime(:)<=0)=1;
        
        if controltime(1)==controltime(2)
            msgbox('control time ʱ�䷶Χ���ô���������ʼʱ�������Ƿ���ȷ!!');
            return
        end
        if controltime(1)>controltime(2)
            p= controltime(1);
            controltime(1)=controltime(2);
            controltime(2)=p;
            set(handles.control_plot_1,'String',num2str(controltime(1)));
            set(handles.control_plot_2,'String',num2str(controltime(2)));
        end
        %% ����
        values=passdata.cal(:,cal_index+1);
        time_index=(1:1:size(passdata.cal,1))*interval;
        ss=find(abs(time_index-controltime(1))==min(abs(time_index-controltime(1))));
        ee=find(abs(time_index-controltime(2))==min(abs(time_index-controltime(2))));
        controldata=values(ss:ee);
        
        if isempty(evaluationtime)
            evaluationdata=values;
            ss=1;
            evaluationtime(1)=0;
            evaluationtime(2)=time_index(end);
            ee=length(time_index);
        else
            ss=find(abs(time_index-evaluationtime(1))==min(abs(time_index-evaluationtime(1))));
            ee=find(abs(time_index-evaluationtime(2))==min(abs(time_index-evaluationtime(2))));
            evaluationdata=values(ss:ee);
        end
        %% plot
        if zscore==1
            figure('NumberTitle', 'off', 'Name', 'z_score data Preview ');
            plot(time_index(ss:ee),(evaluationdata-mean(controldata))/std(controldata));
            xlabel('Time (s)');
            ylabel('z-score');
            data=(evaluationdata-mean(controldata))/std(controldata);
        else
            figure('NumberTitle', 'off', 'Name', 'deltaF/F(%) data Preview ');
            plot(time_index(ss:ee),(evaluationdata-mean(controldata))/(mean(controldata)-offset)*100);
            xlabel('Time (s)');
            ylabel('deltaF/F(%)');
            data=(evaluationdata-mean(controldata))/(mean(controldata)-offset)*100;
        end
        data=data;
        times=time_index(ss:ee);
        %% save data
        save(strrep(passdata.file_path_and_name_cal,passdata.file_part_cal,'_Plot.mat'),'times','data','evaluationtime','controltime');
    end
end


% --- Executes on button press in PlayBack_plot.
function PlayBack_plot_Callback(hObject, eventdata, handles)
% hObject    handle to PlayBack_plot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc
global passdata;
handles=guidata(hObject);
[filename, pathname] = uigetfile({'*.mat'}, 'MultiSelect','off','Open trail_data file',passdata.readpath);
if isequal(filename,0)
    return;
end
filename = fullfile(pathname, filename);
[~,~,file_part_trail]=fileparts(filename);
if strcmp(file_part_trail,'.mat')

    data=load(filename);
    if ~isfield(data,'data')
        msgbox('Failed!Please make sure the trail data is correct !!!!');
        
        return
    end
   
    figure('NumberTitle', 'off', 'Name', 'Trail data Preview ');
    plot(data.times,data.data);
    
    ylabel('deltaF/F(%)');
    
else
    msgbox('Failed!Please make sure the data is correct !!!!');
    return;
end
guidata(hObject,handles)


% --------------------------------------------------------------------



function time_insert_Callback(hObject, eventdata, handles)
% hObject    handle to time_insert (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of time_insert as text
%        str2double(get(hObject,'String')) returns contents of time_insert as a double


% --- Executes during object creation, after setting all properties.
function time_insert_CreateFcn(hObject, eventdata, handles)
% hObject    handle to time_insert (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in InsertMark.
function InsertMark_Callback(hObject, eventdata, handles)
% hObject    handle to InsertMark (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc
global passdata
if isfield(passdata,'cal')
    EditInputMark=get(handles.EditInputMark,'Value');
    if EditInputMark==1
        if isfield(passdata,'cue')
            insert_time=str2num(get(handles.time_insert,'String'));
            if isempty(insert_time)
                return
            end
            if ~isempty(passdata.cue)
                %%
                if insert_time<size(passdata.cal,1)*passdata.interval_cal
                    if isempty(passdata.MarkIndex)
                        %% fpsmark�洢�ߵ����ֵ����Сֵ
                        passdata.fpsmark=[passdata.minwave;passdata.maxwave];
                    else
                        delete(passdata.linefig);
                        passdata.fpsmark=[passdata.fpsmark,passdata.fpsmark(:,1)];
                    end
                    passdata.MarkIndex=sort([passdata.MarkIndex,insert_time]);
                else
                    msgbox('�������ã�������ʱ��㳬����ʱ��������')
                    return
                end
                %% ��ͼ���´洢mark
                linex=[passdata.MarkIndex;passdata.MarkIndex];
                passdata.linefig=line(linex,passdata.fpsmark,'Color','b','LineWidth',1);
                cueindex=passdata.mode1_channel;
                interval=passdata.interval_cal/(passdata.length_cue/size(passdata.cal,1));
                eval(['passdata.InputMark.upindex_' num2str(cueindex) '=passdata.MarkIndex/interval;']);
                %%
            end
        else
            return
        end
    elseif EditInputMark==0
        insert_time=str2num(get(handles.time_insert,'String'));
        if isempty(insert_time)
            return
        end
        if insert_time<size(passdata.cal,1)*passdata.interval_cal
            %%
            if isempty(passdata.MarkIndex)
                passdata.fpsmark=[passdata.minwave;passdata.maxwave];
            else
                delete(passdata.linefig);
                passdata.fpsmark=[passdata.fpsmark,passdata.fpsmark(:,1)];
            end
            passdata.MarkIndex=sort([passdata.MarkIndex,insert_time]);
            %%
            linex=[passdata.MarkIndex;passdata.MarkIndex];
            passdata.linefig=line(linex,passdata.fpsmark,'Color','b','LineWidth',1);
            passdata.ManualMark_upindex=passdata.MarkIndex;
            
            if ~isempty(passdata.ManualMark_upindex)
                
                passdata.ManualMark_upindex=sort(passdata.ManualMark_upindex);
                listbox_cell=cell(1,1+length(passdata.ManualMark_upindex));
                listbox_cell{1,1}='MarkTime';
                
                for i=2:(1+length(passdata.ManualMark_upindex))
                    listbox_cell{1,i}=num2str(passdata.ManualMark_upindex(i-1));
                end
                if isfield(passdata,'mouseSignindex')
                    if ~isempty(passdata.mouseSignindex)
                        index=passdata.mouseSignindex+1;
                    else
                        index=1+length(passdata.ManualMark_upindex);
                    end
                else
                    index=1+length(passdata.ManualMark_upindex);
                end
                set(handles.MarkTime,'String',listbox_cell);
                set(handles.MarkTime,'Value',1);
            else
                listbox_cell=cell(1,1);
                listbox_cell{1,1}='MarkTime';
                set(handles.MarkTime,'String',listbox_cell);
                set(handles.MarkTime,'Value',1);
            end
        else
            msgbox('�������ã�������ʱ��㳬����ʱ��������')
            return
        end
    end
end


%%%%%%%%%
