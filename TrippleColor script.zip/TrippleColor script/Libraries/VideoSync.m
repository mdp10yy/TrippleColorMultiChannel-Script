function varargout = VideoSync(varargin)
% VIDEOSYNC MATLAB code for VideoSync.fig
%      VIDEOSYNC, by itself, creates a new VIDEOSYNC or raises the existing
%      singleton*.
%
%      H = VIDEOSYNC returns the handle to a new VIDEOSYNC or the handle to
%      the existing singleton*.
%
%      VIDEOSYNC('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in VIDEOSYNC.M with the given input arguments.
%
%      VIDEOSYNC('Property','Value',...) creates a new VIDEOSYNC or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before VideoSync_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to VideoSync_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help VideoSync

% Last Modified by GUIDE v2.5 10-May-2022 11:06:03

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @VideoSync_OpeningFcn, ...
                   'gui_OutputFcn',  @VideoSync_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before VideoSync is made visible.
function VideoSync_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to VideoSync (see VARARGIN)

% Choose default command line output for VideoSync
handles.output = hObject;
% global passdata;
% passdata.videocue1=[];
% passdata.videocue2=[];
% passdata.videocue3=[];
% passdata.videocue4=[];
handles.videocue1=[];
handles.videocue2=[];
handles.videocue3=[];
handles.videocue4=[];

handles.Unpressed = imread('Start.PNG');
handles.Pressed = imread('Stop.PNG');
set(handles.PlayVideo, 'CData', handles.Unpressed);
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes VideoSync wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = VideoSync_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in PlayVideo.
function PlayVideo_Callback(hObject, eventdata, handles)
% hObject    handle to PlayVideo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc
global passdata
handles=guidata(hObject);
if ~isfield(handles,'ReaderObj_1')
    msgbox('��ѡ����Ƶ����֮����ʹ�øù��ܣ�����');
    return
end

if ~isfield(handles,'timedata')
    msgbox('��ѡ����Ƶ��ʱ������֮��ʹ�øù���');
    return
end
if ~isfield(passdata,'time0')
    msgbox('���ȡ���źŵ�ʱ���ļ�֮��ʹ�øù���');
    return
end

if get(handles.PlayVideo,'Value')==1
    clc
    if handles.cal_play_index==1
%         cal_current=passdata.cal_current;
        interval=passdata.interval_cal;
        cal_duration=str2num(get(handles.cal_duration,'String'));
        cal_duration_index=cal_duration/interval;
        handles.cal_duration_num=cal_duration;
        examp=abs(handles.frame_upindex2-handles.frame_upindex2(1)-cal_duration_index);
        handles.video_index= find(examp==min(examp));%I
    end
    handles.frame_index=round(get(handles.slider1,'Value'));
    %%
    video_index=find(handles.video_frame_bine_2-handles.frame_index>=0,1,'first');
    current_frame=handles.frame_index-handles.video_frame_bine(video_index); 
    eval(['handles.Current_frame=read(handles.ReaderObj_' num2str(video_index) ',' num2str(current_frame) ');']);
    %%
    guidata(hObject,handles);
    set(handles.PlayVideo,'CData', handles.Pressed);
    set(handles.Cue1,'Enable','off');
    set(handles.Cue2,'Enable','off');
    set(handles.Cue3,'Enable','off');
    set(handles.Cue4,'Enable','off');
    guidata(hObject,handles);
    axes(handles.axes1);
    start(handles.VideoPlayer);
    tic
elseif get(handles.PlayVideo,'Value')==0
    set(handles.Cue1,'Enable','on');
    set(handles.Cue2,'Enable','on');
    set(handles.Cue3,'Enable','on');
    set(handles.Cue4,'Enable','on');
    handles.VideoPlayer=timerfind;
    set(handles.PlayVideo,'CData', handles.Unpressed);
    stop(handles.VideoPlayer);
end




% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc
if ~isfield(handles,'ReaderObj_1')
    msgbox('��ѡ����Ƶ����֮����ʹ�øù��ܣ�����');
    return
end
global passdata
%% ֹͣ������Ƶ
set(handles.PlayVideo,'CData', handles.Unpressed);
set(handles.PlayVideo,'Value',0);
stop(handles.VideoPlayer);
%% ���û�����
slider_frame_index=round(get(handles.slider1,'Value'));
set(handles.slider1,'Value',slider_frame_index);
%% ���㵱ǰͼ��֡
handles.frame_index=slider_frame_index;
video_frame_bine=handles.video_frame_bine;
video_frame_bine_2=video_frame_bine(2:end);
video_index=find(video_frame_bine_2-handles.frame_index>=0,1,'first');
current_frame=handles.frame_index-video_frame_bine(video_index);
eval(['Current_frame=read(handles.ReaderObj_' num2str(video_index) ',' num2str(current_frame) ');']);
% axes(handles.axes1);
% imshow(Current_frame);
%% ���ź���ʾ
% set(handles.axes1,'xtick',[],'ytick',[]);
% set(handles.axes2,'xtick',[],'XColor',[1,1,1],'box','off');
cal_play_index=handles.cal_play_index;
if cal_play_index==1
    interval=passdata.interval_cal;
    cal_current=passdata.cal_current;
    cal_duration=str2num(get(handles.cal_duration,'String'));
    cal_duration_index=cal_duration/interval;
    handles.cal_duration_num=cal_duration;
    examp=abs(handles.frame_upindex2-handles.frame_upindex2(1)-cal_duration_index);
    handles.video_index= find(examp==min(examp));%I
    if cal_play_index==1
        %% handles.frame_index�洢��ǰ��Ƶ֡    handles.video_index�洢����cal duration�ֽ���
        if (handles.frame_index-handles.start_frame_upindex)<handles.video_index && (handles.frame_index-handles.start_frame_upindex)>0
            axes(handles.axes2);
            index_start=handles.start_frame_upindex;
            
            if index_start<length(cal_current)
                if (handles.frame_upindex2(handles.frame_index))<length(cal_current)
                    t=index_start:1:handles.frame_upindex2(handles.frame_index);
                    t=t*interval;
                    plot(t,cal_current(index_start:handles.frame_upindex2(handles.frame_index))');
                    xlim([index_start*interval index_start*interval+handles.cal_duration_num]);
                else
                    t=index_start:1:length(cal_current);
                    t=t*interval;
                    plot(t,cal_current(index_start:handles.frame_upindex2(handles.frame_index))');
                    xlim([index_start*interval index_start*interval+handles.cal_duration_num]);
                end
            end
            
            
        elseif handles.frame_index>=handles.video_index
            axes(handles.axes2);
            index_end=handles.frame_upindex2(handles.frame_index)*interval;
            index_start=round((index_end-handles.cal_duration_num)/interval);
            if index_start<=0
                index_start=1;
            end
            if index_start<length(cal_current)
                if index_end<=length(cal_current)
                    a=cal_current(index_start:round(index_end/interval))';
                    t=1:1:length(a);
                    t=t*interval+index_start*interval;
                    plot(t,a)                   
                    xlim([t(1) t(end)]);
                else
                    a=cal_current(index_start:end)';
                    t=1:1:length(a);
                    t=t*interval+index_start*interval;
                    plot(t,a)                    
                    xlim([t(1) t(end)]);
                end
            end
        elseif (handles.frame_index-handles.start_frame_upindex)<=0
            
        end
    end
end
image(handles.axes1,Current_frame);
set(handles.axes1,'xtick',[],'ytick',[]);
set(handles.axes2,'xtick',[],'XColor',[1,1,1],'box','off');
%% �ָ���ť����
set(handles.current_frame,'String',num2str(handles.frame_index));
set(handles.Cue1,'Enable','on');
set(handles.Cue2,'Enable','on');
set(handles.Cue3,'Enable','on');
set(handles.Cue4,'Enable','on');
disp(['the number of frame_index =' num2str(handles.frame_index) ';']);
guidata(hObject, handles);



% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in Cue1.
function Cue1_Callback(hObject, eventdata, handles)
% hObject    handle to Cue1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc
global passdata;
handles=guidata(hObject);
if ~isfield(handles,'ReaderObj_1')
    msgbox('��ѡ����Ƶ����֮����ʹ�øù��ܣ�����');
    return
end
if ~isfield(handles,'timedata')
    msgbox('��ѡ����Ƶ��ʱ������֮��ʹ�øù���');
    return
end
if ~isfield(passdata,'time0')
    msgbox('���ȡ���źŵ�ʱ���ļ�֮��ʹ�øù���');
    return
end
%% ��ⲥ����״̬
if get(handles.PlayVideo,'Value')~=0
    return
end
frame_index=handles.frame_index;
% Event_time=handles.timedata(frame_index);
% time0=passdata.time0;
% %%
% exam=handles.timedata{frame_index,1};
% index1=find(exam(:)==' ');
% index2=find(exam(:)=='.');
% if index2(1)-index1==2
%     time_shi=['0' exam(index1+1:index2(1)-1)];
% else
%     time_shi=exam(index1+1:index2(1)-1);
% end
% if index2(2)-index2(1)==2
%     time_fen=['0' exam(index2(1)+1:index2(2)-1)];
% else
%     time_fen=exam(index2(1)+1:index2(2)-1);
% end
% 
% if index2(3)-index2(2)==2
%     time_miao=['0' exam(index2(2)+1:index2(3)-1)];
% else
%     time_miao=exam(index2(2)+1:index2(3)-1);
% end
% if length(exam)-index2(3)==2
%     time_haomiao=['0' exam(index2(3)+1:end)];
% elseif length(exam)-index2(3)==1
%     time_haomiao=['00' exam(index2(3)+1:end)];
% else
%     time_haomiao=exam(index2(3)+1:end);
% end
% exam=[exam(1:index1) time_shi '.' time_fen '.' time_miao '.' time_haomiao];
% Event_time=datenum(exam,'yyyy-mm-dd HH.MM.SS.FFF'); 
%%
% Event_time=datenum(Event_time,'yyyy-mm-dd HH.MM.SS.FFF');
Event_time=handles.timedata(frame_index);
time_cal_duration=passdata.time_duration;
if Event_time<=0||Event_time>=time_cal_duration
    msgbox('����ʧ��!! ��ǰʱ��㳬���˸��źŵ�ʵ�ʲɼ�ʱ�䣬���������� !!!');
    return
end
handles.videocue1=[handles.videocue1,Event_time];
guidata(hObject,handles);
msgbox('VideoCue1 ������óɹ�!!!!');



% --- Executes on button press in Cue2.
function Cue2_Callback(hObject, eventdata, handles)
% hObject    handle to Cue2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc
global passdata;
handles=guidata(hObject);
if ~isfield(handles,'ReaderObj_1')
    msgbox('��ѡ����Ƶ����֮����ʹ�øù��ܣ�����');
    return
end
if ~isfield(handles,'timedata')
    msgbox('��ѡ����Ƶ��ʱ������֮��ʹ�øù���');
    return
end
if ~isfield(passdata,'time0')
    msgbox('���ȡ���źŵ�ʱ���ļ�֮��ʹ�øù���');
    return
end
%% ��ⲥ����״̬
if get(handles.PlayVideo,'Value')~=0
    return
end
frame_index=handles.frame_index;
Event_time=handles.timedata(frame_index);
% time0=passdata.time0;
% %%
% exam=handles.timedata{frame_index,1};
% index1=find(exam(:)==' ');
% index2=find(exam(:)=='.');
% if index2(1)-index1==2
%     time_shi=['0' exam(index1+1:index2(1)-1)];
% else
%     time_shi=exam(index1+1:index2(1)-1);
% end
% if index2(2)-index2(1)==2
%     time_fen=['0' exam(index2(1)+1:index2(2)-1)];
% else
%     time_fen=exam(index2(1)+1:index2(2)-1);
% end
% 
% if index2(3)-index2(2)==2
%     time_miao=['0' exam(index2(2)+1:index2(3)-1)];
% else
%     time_miao=exam(index2(2)+1:index2(3)-1);
% end
% if length(exam)-index2(3)==2
%     time_haomiao=['0' exam(index2(3)+1:end)];
% elseif length(exam)-index2(3)==1
%     time_haomiao=['00' exam(index2(3)+1:end)];
% else
%     time_haomiao=exam(index2(3)+1:end);
% end
% exam=[exam(1:index1) time_shi '.' time_fen '.' time_miao '.' time_haomiao];
% Event_time=datenum(exam,'yyyy-mm-dd HH.MM.SS.FFF'); 
% %%
% % Event_time=datenum(Event_time,'yyyy-mm-dd HH.MM.SS.FFF');
% Event_time=(Event_time-time0)*24*60*60;
time_cal_duration=passdata.time_duration;
if Event_time<=0||Event_time>=time_cal_duration
    msgbox('����ʧ��!! ��ǰʱ��㳬���˸��źŵ�ʵ�ʲɼ�ʱ�䣬���������� !!! !!!');
    return
end
handles.videocue2=[handles.videocue2,Event_time];

guidata(hObject,handles);
msgbox('VideoCue2 ������óɹ� !!!!');


% --- Executes on button press in Cue3.
function Cue3_Callback(hObject, eventdata, handles)
% hObject    handle to Cue3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc
global passdata;
handles=guidata(hObject);
if ~isfield(handles,'ReaderObj_1')
    msgbox('��ѡ����Ƶ����֮����ʹ�øù��ܣ�����');
    return
end
if ~isfield(handles,'timedata')
    msgbox('��ѡ����Ƶ��ʱ������֮��ʹ�øù���');
    return
end
if ~isfield(passdata,'time0')
    msgbox('���ȡ���źŵ�ʱ���ļ�֮��ʹ�øù���');
    return
end
%% ��ⲥ����״̬
if get(handles.PlayVideo,'Value')~=0
    return
end
frame_index=handles.frame_index;
Event_time=handles.timedata(frame_index);
%%
% exam=handles.timedata{frame_index,1};
% index1=find(exam(:)==' ');
% index2=find(exam(:)=='.');
% if index2(1)-index1==2
%     time_shi=['0' exam(index1+1:index2(1)-1)];
% else
%     time_shi=exam(index1+1:index2(1)-1);
% end
% if index2(2)-index2(1)==2
%     time_fen=['0' exam(index2(1)+1:index2(2)-1)];
% else
%     time_fen=exam(index2(1)+1:index2(2)-1);
% end
% 
% if index2(3)-index2(2)==2
%     time_miao=['0' exam(index2(2)+1:index2(3)-1)];
% else
%     time_miao=exam(index2(2)+1:index2(3)-1);
% end
% if length(exam)-index2(3)==2
%     time_haomiao=['0' exam(index2(3)+1:end)];
% elseif length(exam)-index2(3)==1
%     time_haomiao=['00' exam(index2(3)+1:end)];
% else
%     time_haomiao=exam(index2(3)+1:end);
% end
% exam=[exam(1:index1) time_shi '.' time_fen '.' time_miao '.' time_haomiao];
% Event_time=datenum(exam,'yyyy-mm-dd HH.MM.SS.FFF'); 
% %%
% % Event_time=datenum(Event_time,'yyyy-mm-dd HH.MM.SS.FFF');
% time0=passdata.time0;
% Event_time=(Event_time-time0)*24*60*60;
time_cal_duration=passdata.time_duration;
if Event_time<=0||Event_time>=time_cal_duration
    msgbox('����ʧ��!! ��ǰʱ��㳬���˸��źŵ�ʵ�ʲɼ�ʱ�䣬���������� !!!');
    return
end
handles.videocue3=[handles.videocue3,Event_time];

guidata(hObject,handles);
msgbox('VideoCue3 ������óɹ� !!!!');


% --- Executes on button press in Cue4.
function Cue4_Callback(hObject, eventdata, handles)
% hObject    handle to Cue4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc
global passdata;
handles=guidata(hObject);
if ~isfield(handles,'ReaderObj_1')
    msgbox('��ѡ����Ƶ����֮����ʹ�øù��ܣ�����');
    return
end
if ~isfield(handles,'timedata')
    msgbox('��ѡ����Ƶ��ʱ������֮��ʹ�øù���');
    return
end
if ~isfield(passdata,'time0')
    msgbox('���ȡ���źŵ�ʱ���ļ�֮��ʹ�øù���');
    return
end
%% ��ⲥ����״̬
if get(handles.PlayVideo,'Value')~=0
    return
end
frame_index=handles.frame_index;
Event_time=handles.timedata(frame_index);
%%
% exam=handles.timedata{frame_index,1};
% index1=find(exam(:)==' ');
% index2=find(exam(:)=='.');
% if index2(1)-index1==2
%     time_shi=['0' exam(index1+1:index2(1)-1)];
% else
%     time_shi=exam(index1+1:index2(1)-1);
% end
% if index2(2)-index2(1)==2
%     time_fen=['0' exam(index2(1)+1:index2(2)-1)];
% else
%     time_fen=exam(index2(1)+1:index2(2)-1);
% end
% 
% if index2(3)-index2(2)==2
%     time_miao=['0' exam(index2(2)+1:index2(3)-1)];
% else
%     time_miao=exam(index2(2)+1:index2(3)-1);
% end
% if length(exam)-index2(3)==2
%     time_haomiao=['0' exam(index2(3)+1:end)];
% elseif length(exam)-index2(3)==1
%     time_haomiao=['00' exam(index2(3)+1:end)];
% else
%     time_haomiao=exam(index2(3)+1:end);
% end
% exam=[exam(1:index1) time_shi '.' time_fen '.' time_miao '.' time_haomiao];
% Event_time=datenum(exam,'yyyy-mm-dd HH.MM.SS.FFF'); 
% %%
% % Event_time=datenum(Event_time,'yyyy-mm-dd HH.MM.SS.FFF');
% time0=passdata.time0;
% Event_time=(Event_time-time0)*24*60*60;
time_cal_duration=passdata.time_duration;
if Event_time<=0||Event_time>=time_cal_duration
    msgbox('����ʧ��!! ��ǰʱ��㳬���˸��źŵ�ʵ�ʲɼ�ʱ�䣬���������� !!!');
    return
end
handles.videocue4=[handles.videocue4,Event_time];
guidata(hObject,handles);
msgbox('VideoCue4 ������óɹ� !!!!');




function current_frame_Callback(hObject, eventdata, handles)
% hObject    handle to current_frame (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function current_frame_CreateFcn(hObject, eventdata, handles)
% hObject    handle to current_frame (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in GoTo.
function GoTo_Callback(hObject, eventdata, handles)
% hObject    handle to GoTo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc
global passdata
handles=guidata(hObject);
if ~isfield(handles,'ReaderObj_1')
    msgbox('���ȡ��Ƶ����֮����ʹ�øù��ܣ�����');
    return
end

%% ���û�����
slider_frame_index=round(str2num(get(handles.current_frame,'String')));
if isempty(slider_frame_index)
    return
else
    if (slider_frame_index>handles.frames_all)||(slider_frame_index<=0)
        return
    end
end

set(handles.slider1,'Value',slider_frame_index);
%% ֹͣ������Ƶ
set(handles.PlayVideo,'CData', handles.Unpressed);
set(handles.PlayVideo,'Value',0);
stop(handles.VideoPlayer);
%% ���㵱ǰͼ��֡
handles.frame_index=slider_frame_index;
video_frame_bine=handles.video_frame_bine;
video_frame_bine_2=video_frame_bine(2:end);
video_index=find(video_frame_bine_2-handles.frame_index>=0,1,'first');
current_frame=handles.frame_index-video_frame_bine(video_index);
eval(['Current_frame=read(handles.ReaderObj_' num2str(video_index) ',' num2str(current_frame) ');']);


%% ���ź���ʾ

cal_play_index=handles.cal_play_index;
if cal_play_index==1
    interval=passdata.interval_cal;
    cal_current=passdata.cal_current;
    cal_duration=str2num(get(handles.cal_duration,'String'));
    cal_duration_index=cal_duration/interval;
    handles.cal_duration_num=cal_duration;
    examp=abs(handles.frame_upindex2-handles.frame_upindex2(1)-cal_duration_index);
    handles.video_index= find(examp==min(examp));%I
    if cal_play_index==1
 
        if (handles.frame_index-handles.start_frame_upindex)<handles.video_index && (handles.frame_index-handles.start_frame_upindex)>0
            axes(handles.axes2);
            index_start=handles.start_frame_upindex;
            
            if index_start<length(cal_current)
                if (handles.frame_upindex2(handles.frame_index))<length(cal_current)
                    t=index_start:1:handles.frame_upindex2(handles.frame_index);
                    t=t*interval;
                    plot(t,cal_current(index_start:handles.frame_upindex2(handles.frame_index))');
                    xlim([index_start*interval index_start*interval+handles.cal_duration_num]);
                else
                    t=index_start:1:length(cal_current);
                    t=t*interval;
                    plot(t,cal_current(index_start:handles.frame_upindex2(handles.frame_index))');
                    xlim([index_start*interval index_start*interval+handles.cal_duration_num]);
                end
            end
            
            
        elseif handles.frame_index>=handles.video_index
            axes(handles.axes2);
            index_end=handles.frame_upindex2(handles.frame_index)*interval;
            index_start=round((index_end-handles.cal_duration_num)/interval);
            if index_start<=0
                index_start=1;
            end
            if index_start<length(cal_current)
                if index_end<=length(cal_current)
                    a=cal_current(index_start:round(index_end/interval))';
                    t=1:1:length(a);
                    t=t*interval+index_start*interval;
                    plot(t,a)                   
                    xlim([t(1) t(end)]);
                else
                    a=cal_current(index_start:end)';
                    t=1:1:length(a);
                    t=t*interval+index_start*interval;
                    plot(t,a)                    
                    xlim([t(1) t(end)]);
                end
            end
        elseif (handles.frame_index-handles.start_frame_upindex)<=0
            
        end
    end
end
image(handles.axes1,Current_frame);
set(handles.axes1,'xtick',[],'ytick',[]);
set(handles.axes2,'xtick',[],'XColor',[1,1,1],'box','off');
%% �ָ���ť����
set(handles.current_frame,'String',num2str(handles.frame_index));
set(handles.Cue1,'Enable','on');
set(handles.Cue2,'Enable','on');
set(handles.Cue3,'Enable','on');
set(handles.Cue4,'Enable','on');
disp(['the number of frame_index =' num2str(handles.frame_index) ';']);
guidata(hObject, handles);



% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over slider1.


% --------------------------------------------------------------------
function LoadVideo_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to LoadVideo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%%   ��ȡVideo����
clc
handles=guidata(hObject);
global passdata;
if ~isfield(handles,'timedata')
    msgbox('���ȶ�ȡ��Ƶͬ���������ɵĸ��ź��ļ����ڶ�ȡ��Ƶ������');
    return
end

if isfield(passdata,'readpath')
    [filename,filepath]=uigetfile({'*.avi'},'Open Video data','MultiSelect','on',passdata.readpath);
else
    [filename,filepath]=uigetfile({'*.avi'},'Open Video data','MultiSelect','on');
end
if isequal(filename,0)
    return;
end
passdata.readpath=filepath(1:end-1);
%% ���ư�ť����
set(handles.Cue1,'Enable','off');
set(handles.Cue2,'Enable','off');
set(handles.Cue3,'Enable','off');
set(handles.Cue4,'Enable','off');
set(handles.PlayVideo,'Enable','off');
set(handles.LoadVideo,'Enable','off');
set(handles.slider1,'Enable','off');
%% end
if ischar(filename)
    VideoNum=1;
    pathstring=[filepath,filename];
    [~,~,part]=fileparts(pathstring);
    if ~strcmp(part,'.avi')
        msgbox('���ȡavi��ʽ����Ƶ�ļ� !!');
        return
    end
    handles.ReaderObj_1=VideoReader(pathstring);
    %% ��¼��Ƶ��֡��
    video_frame_num=zeros(VideoNum,1);
    video_frame_num(1,1)=handles.ReaderObj_1.NumberOfFrames;
else
    VideoNum=size(filename,2);
    %% ��¼��Ƶ��֡��
    video_frame_num=zeros(VideoNum,1);
    for i=1:VideoNum
        pathstring=[filepath,filename(i)];
        [~,~,part]=fileparts(pathstring);
        if ~strcmp(part,'.avi')
            msgbox('���ȡavi��ʽ����Ƶ�ļ� !!');
            return
        end
        ReaderObj=VideoReader(pathstring);
        eval(['handles.ReaderObj_' num2str(i) '=ReaderObj;']);
        eval(['video_frame_num(' num2str(i) ')=handles.ReaderObj_' num2str(i) '.NumberOfFrames;']);
    end
end
handles.video_frame_num=video_frame_num;
handles.VideoNum=VideoNum;
handles.frames_all=sum(video_frame_num);
%% ���Ÿ��ź�ģ��
if sum(video_frame_num)~=length(handles.timedata)
    if abs(length(handles.timedata)-sum(video_frame_num))>5
        choice=questdlg('The video frames are not equal to the Sync_Num, whether to reselect the video !!!','Selection Dialog','Yes','No','No');
        switch choice
            case 'Yes'
                handles.cal_play_index=0;
                set(handles.Cue1,'Enable','on');
                set(handles.Cue2,'Enable','on');
                set(handles.Cue3,'Enable','on');
                set(handles.Cue4,'Enable','on');
                set(handles.PlayVideo,'Enable','on');
                set(handles.Load_Video,'Enable','on');
                set(handles.slider1,'Enable','on');
                return
            case 'No'
                handles.cal_play_index=0;
        end
        
    else
        handles.cal_play_index=1;
        handles.frame_upindex2=round(handles.timedata/passdata.interval_cal);
        handles.frame_upindex2(handles.frame_upindex2(:)<=0)=0;
        index=find(handles.frame_upindex2>0);
        if isempty(index)
            handles.cal_play_index=0;
        else
            handles.start_frame_upindex=handles.frame_upindex2(index(1));
            handles.end_frame_upindex=handles.frame_upindex2(end);
        end
    end
    %% ����
    %   handles.frame_upindex2�洢����Ƶͬ����ʱ��/interval��Ҳ���ڸ��ź��еı�ţ�
    %   
    %%
    %%
else
    handles.cal_play_index=1;
    handles.frame_upindex2=round(handles.timedata/passdata.interval_cal);
    handles.frame_upindex2(handles.frame_upindex2(:)<=0)=0;
    index=find(handles.frame_upindex2>0);
    if isempty(index)
        handles.cal_play_index=0;
    else
        handles.start_frame_upindex=handles.frame_upindex2(index(1));
        handles.end_frame_upindex=handles.frame_upindex2(end);
    end
%         
%     handles.start_frame_upindex=handles.frame_upindex2(1);
%     handles.end_frame_upindex=handles.frame_upindex2(end);
end
%% ��¼ǰn����Ƶ��֡���ܺ�
for i=1:VideoNum
    video_frame_bine(i+1)=sum(video_frame_num(1:i));
end
handles.video_frame_bine=video_frame_bine;
handles.video_frame_bine_2=video_frame_bine(2:end);
guidata(hObject,handles);
%%
Current_frame = read(handles.ReaderObj_1,1);
%% ��ʱ��
handles.VideoPlayer=timer;
timerPeriod=1/30;
%% ���û�����
set(handles.slider1,'Max',handles.frames_all);
set(handles.slider1,'Min',1);
set(handles.slider1,'Value',1);
set(handles.slider1,'SliderStep',[1/(handles.frames_all-1), 10/(handles.frames_all-1)]);
%% 
set(handles.current_frame,'String',num2str(1));
set(handles.VideoPlayer,'Period',timerPeriod,'TimerFcn',{@Video_Player,handles},'ExecutionMode','fixedRate');
axes(handles.axes1);
imshow(Current_frame);
handles.frame_index=1;
%% ��ť�ָ�����
set(handles.PlayVideo,'CData', handles.Unpressed);
set(handles.PlayVideo,'Value',0);
set(handles.Cue1,'Enable','on');
set(handles.Cue2,'Enable','on');
set(handles.Cue3,'Enable','on');
set(handles.Cue4,'Enable','on');
set(handles.PlayVideo,'Enable','on');
set(handles.LoadVideo,'Enable','on');
set(handles.slider1,'Enable','on');
%%
guidata(hObject,handles);
msgbox('��Ƶ��ȡ�ɹ� !!!!!');


% --------------------------------------------------------------------
function LoadTimeStamp_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to LoadTimeStamp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%%   ��ȡTXT����
clc
global passdata;
handles=guidata(hObject);

if ~isfield(passdata,'time0')
    msgbox('���ȡ���źŵ�ʱ���ļ�֮��ʹ�øù���');
    return
end

if isfield(passdata,'readpath')
    [filenametxt,filepathtxt]=uigetfile({'*.TXT'},'Open txt_data file','MultiSelect','off',passdata.readpath);
else
    [filenametxt,filepathtxt]=uigetfile({'*.TXT'},'Open txt_data file','MultiSelect','off');
end
if isequal(filenametxt,0)
    return;
end
fullfiletxt=fullfile(filepathtxt,filenametxt);
[~,~,file_part_trail]=fileparts(fullfiletxt);
passdata.readpath=filepathtxt(1:end-1);
if ~strcmp(file_part_trail,'.TXT') && ~strcmp(file_part_trail,'.txt')
    msgbox('����ʧ�ܣ����ȡ��ȷ����Ƶʱ���ļ�  !!!!');
    return;
end



timedata=importdata(fullfiletxt);
Event_time=zeros(length(timedata),1);

for i=1:length(timedata)

    exam=timedata{i,1};
    index1=find(exam(:)==' ');
    index2=find(exam(:)=='.');
    if index2(1)-index1==2
        time_shi=['0' exam(index1+1:index2(1)-1)];
    else
        time_shi=exam(index1+1:index2(1)-1);
    end
    if index2(2)-index2(1)==2
        time_fen=['0' exam(index2(1)+1:index2(2)-1)];
    else
        time_fen=exam(index2(1)+1:index2(2)-1);
    end
    
    if index2(3)-index2(2)==2
        time_miao=['0' exam(index2(2)+1:index2(3)-1)];
    else
        time_miao=exam(index2(2)+1:index2(3)-1);
    end
    if length(exam)-index2(3)==2
        time_haomiao=['0' exam(index2(3)+1:end)];
    elseif length(exam)-index2(3)==1
        time_haomiao=['00' exam(index2(3)+1:end)];
    else
        time_haomiao=exam(index2(3)+1:end);
    end
    exam=[exam(1:index1) time_shi '.' time_fen '.' time_miao '.' time_haomiao];
    Event_time(i)=datenum(exam,'yyyy-mm-dd HH.MM.SS.FFF');
    %     end
end
clear timedata;
handles.timedata=(Event_time-passdata.time0)*24*60*60;

guidata(hObject,handles);
msgbox('ʱ���ļ���ȡ�ɹ� !!!');
guidata(hObject,handles);

%% end


% --- Executes on button press in SaveVideoMark.
function SaveVideoMark_Callback(hObject, eventdata, handles)
% hObject    handle to SaveVideoMark (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc
handles=guidata(hObject);
global passdata
if isempty(handles.videocue1)&&isempty(handles.videocue2)&&isempty(handles.videocue3)&&isempty(handles.videocue4)
    msgbox('δ��⵽��Ƶ����ǵ㣬���������ã�����');
    return;
end
data.videocue1=handles.videocue1;
data.videocue2=handles.videocue2;
data.videocue3=handles.videocue3;
data.videocue4=handles.videocue4;

passdata.videocue1=handles.videocue1;
passdata.videocue2=handles.videocue2;
passdata.videocue3=handles.videocue3;
passdata.videocue4=handles.videocue4;

if isfield(passdata,'file_path_and_name_cal')
    name=strrep(passdata.file_path_and_name_cal,passdata.file_part_cal,'_Videomark.mat');
else
    name=[passdata.readpath,'\Videomark.mat'];
%     name=save(strrep(passdata.file_path_and_name_cal,passdata.file_part_cal,'_Videomark.mat'),'data');
end

dig=['�Ƿ���Ҫ����Ϊ���ݣ����ѡ��no���ļ��������� ' name '!!!'];
choice=questdlg(dig, ...
    'Selection Dialog', ...
    'Yes', 'No','No');

if isempty(choice)
    save(name,'data');
else
    if strcmp(choice,'No')
        save(name,'data');
    elseif strcmp(choice,'Yes')
        [SaveFileName,SavePathName,SaveIndex] = uiputfile('*.mat;','Save as',passdata.readpath); %����Ĭ��·��
        if isequal(SaveFileName,0) || isequal(SavePathName,0) || isequal(SaveIndex,0)
            disp('User seleceted Cancel');
            save(name,'data');
        else
            path=[SavePathName SaveFileName];
            save(path,'data');
        end
    end
end
msgbox('�����ɹ� !!!');
guidata(hObject,handles);



% --- Executes on button press in Cue1Reset.
% function Cue1Reset_Callback(hObject, eventdata, handles)
% % hObject    handle to Cue1Reset (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% clc
% global passdata;
% dig=['��ȷ���Ƿ����VideoCue1���õĴ��ʱ������ݣ�'];
% choice=questdlg(dig, ...
%     'Selection Dialog', ...
%     'Yes', 'No','No');
% if isempty(choice)
%     msgbox('User cancel operation !!!');
%     return
% else
%     if strcmp(choice,'No')
%         msgbox('User cancel operation !!!!');
%         return
%     else
%         %% clear mark
%         passdata.videocue1=[];
%     end
% end
% 
% 
% % --- Executes on button press in Cue2Reset.
% function Cue2Reset_Callback(hObject, eventdata, handles)
% % hObject    handle to Cue2Reset (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% clc
% global passdata;
% dig=['��ȷ���Ƿ����VideoCue2���õĴ��ʱ������ݣ�'];
% choice=questdlg(dig, ...
%     'Selection Dialog', ...
%     'Yes', 'No','No');
% if isempty(choice)
%     msgbox('User cancel operation !!!');
%     return
% else
%     if strcmp(choice,'No')
%         msgbox('User cancel operation !!!!');
%         return
%     else
%         %% clear mark
%         passdata.videocue2=[];
%     end
% end
% 
% 
% % --- Executes on button press in Cue3Reset.
% function Cue3Reset_Callback(hObject, eventdata, handles)
% % hObject    handle to Cue3Reset (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% clc
% global passdata;
% dig=['��ȷ���Ƿ����VideoCue3���õĴ��ʱ������ݣ�'];
% choice=questdlg(dig, ...
%     'Selection Dialog', ...
%     'Yes', 'No','No');
% if isempty(choice)
%     msgbox('User cancel operation !!!');
%     return
% else
%     if strcmp(choice,'No')
%         msgbox('User cancel operation !!!!');
%         return
%     else
%         %% clear mark
%         passdata.videocue3=[];
%     end
% end
% 
% 
% % --- Executes on button press in Cue4Reset.
% function Cue4Reset_Callback(hObject, eventdata, handles)
% % hObject    handle to Cue4Reset (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% clc
% global passdata;
% dig=['��ȷ���Ƿ����VideoCue4���õĴ��ʱ������ݣ�'];
% choice=questdlg(dig, ...
%     'Selection Dialog', ...
%     'Yes', 'No','No');
% if isempty(choice)
%     msgbox('User cancel operation !!!');
%     return
% else
%     if strcmp(choice,'No')
%         msgbox('User cancel operation !!!!');
%         return
%     else
%         %% clear mark
%         passdata.videocue4=[];
%     end
% end



function cal_duration_Callback(hObject, eventdata, handles)
% hObject    handle to cal_duration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of cal_duration as text
%        str2double(get(hObject,'String')) returns contents of cal_duration as a double


% --- Executes during object creation, after setting all properties.
function cal_duration_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cal_duration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
